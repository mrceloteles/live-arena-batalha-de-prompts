// Portão 2 de 3: a cascata por ELEMENTO, na tela renderizada.
//
// Para cada elemento de cada tela, fotografa o estilo computado e guarda uma
// impressão digital. Qualquer mudança de estilo carimbada que mude o que o
// navegador resolve faz este teste reprovar — inclusive a que o portão 1 não
// consegue ver: um seletor que passa a ganhar (ou a perder) de OUTRO seletor no
// mesmo elemento (`.brand-identity` contra `.brand-identity--small`,
// `.report-date-field` contra `.text-field`).
//
// Só estilo, sem geometria: as medidas de caixa oscilam alguns sub-pixels entre
// duas capturas do MESMO estado (largura de texto), e comparar isso daria
// reprovação falsa. A geometria é consequência do estilo, então o estilo é o
// lugar certo para o portão.
//
// Se a mudança for intencional, regenere e revise o diff:
//   UPDATE_CSS_BASELINE=1 npm run test:browser
// Para saber QUEM causou uma reprovação, o instrumento detalhado é
// `tmp/qa/blame-faixa.mjs` (comparação de dois estados, com o seletor culpado).
//
// A suíte de navegador roda com `--test-concurrency=1` (ver `package.json`):
// cada arquivo levanta um navegador de verdade, e três ao mesmo tempo nesta
// máquina faziam um `page.goto` estourar o tempo limite de 30s de vez em quando.
// Um portão intermitente ensina a rodar de novo até ficar verde, que é
// exatamente como uma regressão de verdade passa despercebida.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import test, { after, before } from 'node:test';

import { openDatabase } from '../../src/db/database.mjs';
import { createRepositories } from '../../src/db/repositories/index.mjs';
import { createFakeJudge } from '../../src/judge/fake-judge.mjs';
import { createApplication } from '../../src/server/start.mjs';
import { FOLHAS, FOLHA_DE_CONTRATO } from '../support/cascata-css.mjs';
import { abrirNavegador } from '../support/navegador.mjs';

const raiz = new URL('../../', import.meta.url);
const cartorio = new URL('test/css/render.json', raiz);
// Estritamente '1' — ver a nota em test/css/cascata.test.mjs.
const atualizar = process.env.UPDATE_CSS_BASELINE === '1';
const saida = new URL('tmp/qa/css-render/', raiz);
const SENHA = 'css-baseline-password';
const SEGREDO = 'css-baseline-secret-at-least-32-characters';

// Propriedades de estilo. Fora da lista: as medidas de caixa (`width`, `height`,
// `top/right/bottom/left`, `min-*`, `max-*`) e os `grid-template-*`, que o
// navegador devolve já resolvidos em pixels e oscilam entre capturas do mesmo
// estado.
const PROPS = [
  'display', 'position', 'z-index', 'float', 'visibility', 'opacity',
  'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
  'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
  'border-top-width', 'border-right-width', 'border-bottom-width', 'border-left-width',
  'border-top-style', 'border-right-style', 'border-bottom-style', 'border-left-style',
  'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color',
  'border-top-left-radius', 'border-top-right-radius', 'border-bottom-right-radius', 'border-bottom-left-radius',
  'background-color', 'background-image', 'background-size', 'background-position', 'background-repeat',
  'color', 'font-family', 'font-size', 'font-weight', 'font-style', 'letter-spacing',
  'line-height', 'text-align', 'text-transform', 'text-decoration-line', 'white-space',
  'text-overflow', 'text-shadow', 'overflow-x', 'overflow-y', 'cursor', 'pointer-events',
  'box-shadow', 'filter', 'backdrop-filter', 'mix-blend-mode', 'object-fit', 'aspect-ratio',
  'flex-direction', 'flex-wrap', 'justify-content', 'align-items', 'align-self',
  'flex-grow', 'flex-shrink', 'flex-basis', 'gap', 'order',
  'grid-column', 'grid-row', 'column-gap', 'row-gap',
  'transition', 'clip-path',
];

const LARGURAS = [
  [1440, 900],
  [390, 844],
];

let servidor;
let navegador;
let base;
let cookieAdmin;
let cookieTv;
let codigoDaSala;
let pinDaSala;
const folhasCarregadas = new Set();

/**
 * Só o que o CSS decide — nada de texto, nada de medida de caixa.
 *
 * Antes de medir, as animações e transições são desligadas por uma folha
 * adotada (não por um `<style>` no documento: isso mudaria os índices dos
 * elementos e portanto o próprio retrato). Sem isso, um elemento que pulsa
 * (a `.arena-tv-pulse` da projeção) tem `box-shadow` diferente a cada captura e
 * o portão reprovaria sozinho.
 */
const fotografar = (props) => {
  const congelar = new CSSStyleSheet();
  congelar.replaceSync('*, *::before, *::after { animation: none !important; transition: none !important; }');
  document.adoptedStyleSheets = [...document.adoptedStyleSheets, congelar];
  const linhas = [];
  for (const elemento of document.querySelectorAll('*')) {
    const caminho = [];
    let no = elemento;
    while (no && no.nodeType === 1 && no !== document.documentElement) {
      const pai = no.parentNode;
      if (!pai) break;
      caminho.unshift(`${no.tagName.toLowerCase()}:${[...pai.children].indexOf(no) + 1}`);
      no = pai;
    }
    const estilo = getComputedStyle(elemento);
    const valores = props.map((p) => `${p}:${estilo.getPropertyValue(p)}`).join(';');
    linhas.push(`${caminho.join('>')}\t${elemento.tagName.toLowerCase()}\t${elemento.getAttribute('class') || ''}\t${valores}`);
  }
  return { elementos: document.querySelectorAll('*').length, texto: linhas.join('\n') };
};

const normalizar = (texto, porta) =>
  texto
    .replaceAll(`127.0.0.1:${porta}`, '127.0.0.1:PORTA')
    .replace(/\r\n/g, '\n');

before(async () => {
  const aberto = openDatabase(':memory:');
  await aberto.migrate();
  const repositories = createRepositories(aberto.database);
  let sequencia = 0;
  servidor = createServer(
    createApplication({
      repositories,
      judge: createFakeJudge(),
      arenaJudge: async ({ candidatePrompt }) => ({
        percent: 50 + Number(/Aluno (\d+)/.exec(String(candidatePrompt || ''))?.[1] || 0),
        breakdown: {},
        feedback: 'Avaliado',
      }),
      adminPassword: SENHA,
      adminSecret: SEGREDO,
      // Relógio parado: nenhuma tela pode mudar de estilo porque o tempo passou.
      now: () => 5000,
      id: () => `css-baseline-${++sequencia}`,
    }),
  );
  await new Promise((resolve) => servidor.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${servidor.address().port}`;

  const postar = async (action, payload = {}, cookie) => {
    const resposta = await fetch(`${base}/api.php?action=${action}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}) },
      body: JSON.stringify(payload),
    });
    const corpo = await resposta.json();
    assert.equal(resposta.status, 200, `${action}: ${JSON.stringify(corpo)}`);
    return { corpo, resposta };
  };

  const login = await fetch(`${base}/api.php?action=admin_login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ password: SENHA }),
  });
  assert.equal(login.status, 200);
  cookieAdmin = login.headers.get('set-cookie').split(';')[0];

  // Uma sala de Arena publicada, com alunos dentro: é ela que dá conteúdo às
  // telas do painel, da projeção e do relatório.
  await postar('arena_set_open', { open: true }, cookieAdmin);
  await postar('arena_create_room', {
    title: 'Sala do portão de CSS', preset: 'arena', expected_players: 8,
    arena_rounds: 2, arena_boss_health: 3, arena_damage_threshold: 60, arena_attacks_per_round: 2,
    arena_teams: true,
  }, cookieAdmin).then(async ({ corpo }) => {
    for (const [indice, missao] of ['Cartaz da feira de ciências.', 'Post do clube de robótica.'].entries()) {
      const { challenge } = (await postar('arena_save_challenge', {
        title: `Missão ${indice + 1}`, modality: 'precisao', mission: missao,
        context: 'Turma do ensino médio.',
        criteria: [{ criterion: 'objetivo', weight: 40 }, { criterion: 'contexto', weight: 30 }, { criterion: 'formato', weight: 30 }],
        reference_text: `Material do projeto com data, local e público. Missão ${indice + 1}.`,
      }, cookieAdmin)).corpo;
      await postar('arena_add_round', { room_id: corpo.room.id, challenge_id: challenge.id }, cookieAdmin);
    }
    await postar('arena_publish_room', { room_id: corpo.room.id }, cookieAdmin);
    for (let n = 1; n <= 4; n += 1) {
      const entrada = await fetch(`${base}/api.php?action=arena_join`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ code: corpo.room.code, name: `Aluno ${n}` }),
      });
      assert.equal(entrada.status, 200);
    }
    codigoDaSala = corpo.room.code;
    pinDaSala = corpo.room.pin || corpo.room.code;
    const tv = await postar('arena_tv_token', { room_id: corpo.room.id }, cookieAdmin);
    cookieTv = tv.resposta.headers.get('set-cookie').split(';')[0];
  });

  navegador = await abrirNavegador();
  mkdirSync(saida, { recursive: true });
});

after(async () => {
  if (navegador) await navegador.close();
  if (servidor) await new Promise((resolve) => servidor.close(resolve));
});

const TELAS = () => [
  ['portal', '/', null],
  ['entrada-do-aluno', '/play', null],
  ['entrada-do-aluno-com-codigo', `/play?pin=${codigoDaSala}`, null],
  ['painel-login', '/admin-arena.php', null],
  ['painel-do-professor', '/admin-arena.php', cookieAdmin],
  ['previa-do-aluno', '/aluno-preview.php', cookieAdmin],
  ['previa-da-tv', '/tv-preview.php', cookieAdmin],
  ['projecao-da-tv', `/tv.php?pin=${pinDaSala}`, cookieTv],
  ['relatorio', '/report.php', cookieAdmin],
];

async function capturar() {
  const porta = new URL(base).port;
  const retratos = {};
  const pagina = await navegador.newPage();
  const sessao = await pagina.createCDPSession();
  pagina.on('response', (resposta) => {
    const caminho = new URL(resposta.url()).pathname;
    if (caminho.endsWith('.css')) folhasCarregadas.add(caminho.split('/').pop());
  });
  try {
    for (const [largura, altura] of LARGURAS) {
      await pagina.setViewport({ width: largura, height: altura, deviceScaleFactor: 1 });
      for (const [nome, url, cookie] of TELAS()) {
        const alvo = new URL(base + url);
        // Cada tela começa limpa: sem isso o cookie do painel continua valendo
        // para as telas seguintes e a "tela de login" era fotografada já
        // autenticada — cobertura perdida sem nenhum aviso.
        await sessao.send('Storage.clearDataForOrigin', { origin: base, storageTypes: 'all' });
        if (cookie) {
          await pagina.setCookie({
            name: cookie.split('=')[0], value: cookie.slice(cookie.indexOf('=') + 1),
            domain: '127.0.0.1', path: '/', httpOnly: true,
          });
        }
        await pagina.goto(alvo.href, { waitUntil: 'networkidle2', timeout: 45_000 });
        await new Promise((resolve) => setTimeout(resolve, 400));
        // Lê até que duas leituras seguidas batam. Uma espera fixa não garante
        // que a tela parou de se montar (as telas buscam dados depois do load),
        // e um retrato tirado no meio da montagem reprova o portão sozinho.
        let estilo = await pagina.evaluate(fotografar, PROPS);
        for (let tentativa = 0; tentativa < 5; tentativa += 1) {
          await new Promise((resolve) => setTimeout(resolve, 250));
          const seguinte = await pagina.evaluate(fotografar, PROPS);
          if (seguinte.texto === estilo.texto && seguinte.elementos === estilo.elementos) break;
          estilo = seguinte;
        }
        const texto = normalizar(estilo.texto, porta);
        const identificador = `${nome}__${largura}x${altura}`;
        retratos[identificador] = {
          elementos: estilo.elementos,
          hash: createHash('sha256').update(texto).digest('hex').slice(0, 16),
        };
        writeFileSync(new URL(`${identificador}.txt`, saida), `# ${url} ${largura}x${altura} elementos=${estilo.elementos}\n${texto}\n`);
      }
    }
  } finally {
    await pagina.close();
  }
  return retratos;
}

test('browser: nenhuma tela muda de estilo sem atualizar o instantâneo', { timeout: 240_000 }, async () => {
  const retratos = await capturar();
  const atual = {
    folhasCarregadas: [...folhasCarregadas].sort(),
    telas: retratos,
  };
  if (atualizar) {
    writeFileSync(cartorio, `${JSON.stringify(atual, null, 2)}\n`);
    return;
  }
  const esperado = JSON.parse(readFileSync(cartorio, 'utf8'));

  const alteradas = [];
  for (const identificador of Object.keys({ ...esperado.telas, ...retratos })) {
    const antes = esperado.telas[identificador];
    const depois = retratos[identificador];
    if (!antes) alteradas.push(`${identificador}: tela nova, não existia no instantâneo`);
    else if (!depois) alteradas.push(`${identificador}: tela desapareceu do teste`);
    else if (antes.hash !== depois.hash) {
      alteradas.push(`${identificador}: o estilo computado mudou (${antes.elementos} -> ${depois.elementos} elementos)`);
    }
  }
  assert.equal(
    alteradas.length,
    0,
    `estilo computado mudou em ${alteradas.length} tela(s):\n  ${alteradas.join('\n  ')}\n\n` +
      `O retrato de agora está em tmp/qa/css-render/ (fora do versionamento).\n` +
      'Se a mudança é intencional e você provou que a tela mudou como queria, regenere:\n' +
      '  UPDATE_CSS_BASELINE=1 npm run test:browser\n',
  );
});

test('browser: toda folha de estilo em disco é carregada por alguma página', { timeout: 240_000 }, async () => {
  if (!folhasCarregadas.size) await capturar();
  const emDisco = readdirSync(new URL('public/assets/css', raiz)).filter((nome) => nome.endsWith('.css'));
  const orfas = emDisco.filter((nome) => nome !== FOLHA_DE_CONTRATO && !folhasCarregadas.has(nome));
  assert.deepEqual(
    orfas,
    [],
    `folhas em disco que nenhuma página carrega: ${orfas.join(', ')}\n` +
      'Ou elas voltaram a alguma página, ou devem ser apagadas (como append.css e neutral.css).',
  );
  for (const folha of FOLHAS) {
    assert.ok(folhasCarregadas.has(folha.nome), `${folha.nome} deixou de ser carregada por alguma página`);
  }
});
